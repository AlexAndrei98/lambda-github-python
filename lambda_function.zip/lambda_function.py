from calendarauto import main
from basil_counter import  count
from alex_fitnesspal import food_analysis
from email_sender import sendemail
import datetime
import time
import json
def lambda_handler(event, context):
    OUTPUT_STRING='Subject: Daily report for Alex\n\n'
    todays_tasks,OUTPUT_STRING = main(OUTPUT_STRING)
    OUTPUT_STRING = count(todays_tasks,OUTPUT_STRING)
    time.sleep(2)
    OUTPUT_STRING = food_analysis(OUTPUT_STRING)
    print(OUTPUT_STRING)
    sendemail(OUTPUT_STRING)
    return {
        "statusCode": 200,
        "body": json.dumps(OUTPUT_STRING)
    }
lambda_handler(1,1)




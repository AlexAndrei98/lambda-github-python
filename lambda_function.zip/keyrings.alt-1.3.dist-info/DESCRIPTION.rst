.. image:: https://img.shields.io/pypi/v/keyrings.alt.svg
   :target: https://pypi.org/project/keyrings.alt

.. image:: https://img.shields.io/pypi/pyversions/keyrings.alt.svg

.. image:: https://img.shields.io/pypi/dm/keyrings.alt.svg

.. image:: https://img.shields.io/travis/jaraco/keyrings.alt/master.svg
   :target: http://travis-ci.org/jaraco/keyrings.alt

Alternate keyring backend implementations for use with the
`keyring package <https://pypi.python.org/pypi/keyring>`_.

Docs
====

There's `no good mechanism for publishing documentation
<https://github.com/pypa/python-packaging-user-guide/pull/266>`_
easily. If there's a documentation link above, it's probably
stale because PyPI-based documentation is deprecated. This
project may have documentation published at ReadTheDocs, but
probably not. Good luck finding it.



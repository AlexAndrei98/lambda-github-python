TOMATO = ''
FLAMINGO = ''
BANANA = 'Lunch'
TANGERINE = ''
SAGE = '' #= 'Joints Sage VAried'
BASIL = 'Joints'
PEACOCK= ''  #= 'Church/Volunteer'
BLUEBERRY = ''
LAVENDER = ''
GRAPE = 'YMCA/Working Out'
GRAPHITE = 'Coding/Work'
sender_email = "allyouneedissbo@gmail.com"
password = 'sofiapiccioni'

color_activity = {
		0 : LAVENDER,
		1 : BLUEBERRY,
		2 : PEACOCK,
		3 : SAGE,
		4 : BASIL,
		5 : TANGERINE,
        6 : BANANA,
        7 : FLAMINGO,
        8 : TOMATO,
        9 : GRAPE,
        10 : GRAPHITE,
	}



from calendarauto import main
import datetime

def count(todays_tasks,OUTPUT_STRING):
    TOTAL_COUNT=0
    SMALL_COUNT = 0
    MEDIUM_COUNT = 0
    BIG_COUNT = 0

    for task in todays_tasks:
        if(task.color == 4):
            TOTAL_COUNT+=1
            #Lunch use myfitnesspal api to get data workout
            #Maybe check for lunch or dinner 
        if(task.name == 'Small' and task.color == 4 ) :
            SMALL_COUNT+=1
        if(task.name == 'Medium' and task.color == 4 ):
            MEDIUM_COUNT+=1
        if(task.name == 'Big' and task.color == 4):
            BIG_COUNT+=1

    OUTPUT_STRING +="\n\nToday you smoked the following:"
    if SMALL_COUNT>0 :
        OUTPUT_STRING+='\nSmall Joints: '+str(SMALL_COUNT)
    if MEDIUM_COUNT>0 :
        OUTPUT_STRING+='\nMedium Joints: '+str(MEDIUM_COUNT)
    if BIG_COUNT>0 :
        OUTPUT_STRING+='\nBig Joints: '+str(BIG_COUNT)
    #ONLY Display total only if you have two or more categories
    if((SMALL_COUNT>0 and MEDIUM_COUNT>0 ) or (SMALL_COUNT>0 and BIG_COUNT>0)or (MEDIUM_COUNT>0 and BIG_COUNT>0)):
        OUTPUT_STRING+='\nFor a total of: '+str(TOTAL_COUNT)

    return OUTPUT_STRING


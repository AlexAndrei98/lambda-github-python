from myfitnesspal.client import Client  # noqa

__version__ = '1.13.3'

VERSION = tuple(int(v) for v in __version__.split('.'))
